#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import hashlib
import hmac
import base64
import time
import os
import sqlite3
from datetime import datetime, timedelta
import traceback

# -------------------------- 配置 --------------------------
CONFIG = {
    "api_key": os.environ.get("API_KEY", "your-secret-api-key-here"),
    "encryption_key": os.environ.get("ENCRYPTION_KEY", "your-encryption-secret-key").encode('utf-8'),
    "rate_limit": int(os.environ.get("RATE_LIMIT", "60")),  # 每分钟最大请求数
    "db_path": os.environ.get("DB_PATH", "/tmp/activation.db"),  # SQLite文件路径，/tmp是云函数临时目录
}

# -------------------------- 数据存储 - SQLite --------------------------
# 注意：腾讯云函数 /tmp 目录是临时存储，函数实例释放后会清除
# 但实例冷启动重新创建会初始化数据库，如果需要持久化，请将SQLite文件放到
# 腾讯云COS挂载或者CFS文件存储中

db_initialized = False
rate_limit_requests = {}

def init_db():
    """初始化数据库表"""
    global db_initialized
    if db_initialized:
        return
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 创建激活码表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS activation_codes (
            auth_code TEXT PRIMARY KEY,
            duration INTEGER NOT NULL,
            package_type TEXT NOT NULL,
            generate_date TEXT NOT NULL,
            activated_date TEXT,
            machine_code TEXT,
            expiry_date TEXT
        )
    ''')
    conn.commit()
    conn.close()
    
    db_initialized = True

def get_db_connection():
    """获取数据库连接"""
    # 确保目录存在
    db_dir = os.path.dirname(CONFIG["db_path"])
    if db_dir and not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)
    
    conn = sqlite3.connect(CONFIG["db_path"])
    conn.row_factory = sqlite3.Row
    return conn

def get_activation_code(auth_code):
    """查询激活码"""
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM activation_codes WHERE auth_code = ?", (auth_code,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None

def update_activation_code(auth_code, data):
    """更新激活码信息"""
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    set_clause = ", ".join([f"{k} = ?" for k in data.keys()])
    sql = f"UPDATE activation_codes SET {set_clause} WHERE auth_code = ?"
    params = list(data.values()) + [auth_code]
    cursor.execute(sql, params)
    conn.commit()
    conn.close()

def insert_activation_code(data):
    """插入新激活码"""
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    columns = ", ".join(data.keys())
    placeholders = ", ".join(["?"] * len(data))
    sql = f"INSERT INTO activation_codes ({columns}) VALUES ({placeholders})"
    cursor.execute(sql, list(data.values()))
    conn.commit()
    conn.close()

# 降级内存存储
fallback_activation_codes = {}

# -------------------------- 加密工具 --------------------------
def encrypt_data(data: dict) -> str:
    """使用HMAC+SHA256加密数据，生成激活码部分"""
    data_str = json.dumps(data, sort_keys=True)
    signature = hmac.new(CONFIG["encryption_key"], data_str.encode('utf-8'), hashlib.sha256).hexdigest()
    combined = f"{data_str}|{signature}"
    return base64.urlsafe_b64encode(combined.encode('utf-8')).decode('utf-8')

def decrypt_data(encrypted: str) -> dict | None:
    """解密并验证激活码数据"""
    try:
        decoded = base64.urlsafe_b64decode(encrypted.encode('utf-8')).decode('utf-8')
        parts = decoded.rsplit('|', 1)
        if len(parts) != 2:
            return None
        data_str, signature = parts
        data = json.loads(data_str)
        
        # 验证签名
        expected_signature = hmac.new(CONFIG["encryption_key"], data_str.encode('utf-8'), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected_signature):
            return None
        return data
    except Exception:
        return None

# -------------------------- 频率限制 --------------------------
def check_rate_limit(client_ip: str) -> bool:
    """检查请求频率限制"""
    now = int(time.time())
    window_start = now - 60  # 1分钟窗口
    
    # 清理过期请求
    if client_ip not in rate_limit_requests:
        rate_limit_requests[client_ip] = []
    
    # 过滤掉过期请求
    requests = [t for t in rate_limit_requests[client_ip] if t > window_start]
    
    if len(requests) >= CONFIG["rate_limit"]:
        return False
    
    requests.append(now)
    rate_limit_requests[client_ip] = requests
    return True

# -------------------------- 接口处理 --------------------------
def handle_verify(body: dict) -> dict:
    """处理激活码验证请求"""
    auth_code = body.get("auth_code")
    machine_code = body.get("machine_code")
    
    if not auth_code or not machine_code:
        return {
            "status": "invalid",
            "message": "缺少必填参数 auth_code 或 machine_code",
            "data": None
        }
    
    # 拆分激活码
    parts = auth_code.split('_', 1)
    if len(parts) != 2:
        return {
            "status": "invalid",
            "message": "激活码格式错误",
            "data": None
        }
    
    # 查询存储
    try:
        info = get_activation_code(auth_code)
        if not info:
            return {
                "status": "invalid",
                "message": "激活码不存在",
                "data": None
            }
    except Exception:
        traceback.print_exc()
        # 降级到内存存储
        if auth_code not in fallback_activation_codes:
            return {
                "status": "invalid",
                "message": "激活码不存在，数据库异常",
                "data": None
            }
        info = fallback_activation_codes[auth_code]
    
    # 检查设备绑定
    if info.get("machine_code") and info["machine_code"] != machine_code:
        return {
            "status": "used",
            "message": "激活码已被其他设备绑定",
            "data": None
        }
    
    # 检查是否过期
    now = datetime.utcnow()
    if info.get("expiry_date"):
        try:
            expiry = datetime.fromisoformat(info["expiry_date"].replace('Z', '+00:00'))
            if now > expiry:
                return {
                    "status": "expired",
                    "message": "激活码已过期",
                    "data": None
                }
        except Exception:
            return {
                "status": "invalid",
                "message": "过期时间格式错误",
                "data": None
            }
    
    # 检查当前过期时间是否一致（可选参数）
    current_expiry = body.get("current_expiry_date")
    if current_expiry and current_expiry != info.get("expiry_date"):
        return {
            "status": "invalid",
            "message": "激活信息已失效，请重新验证",
            "data": None
        }
    
    # 首次激活，绑定设备计算过期时间
    if not info.get("machine_code"):
        info["machine_code"] = machine_code
        info["activated_date"] = datetime.utcnow().isoformat() + 'Z'
        duration = info.get("duration")
        if duration == -1:  # 永久
            info["expiry_date"] = "9999-12-31T23:59:59Z"
        else:
            activated = datetime.fromisoformat(info["activated_date"].replace('Z', '+00:00'))
            expiry = activated + timedelta(days=duration)
            info["expiry_date"] = expiry.isoformat().replace('+00:00', 'Z')
        
        # 更新存储
        try:
            update_data = {
                "machine_code": info["machine_code"],
                "activated_date": info["activated_date"],
                "expiry_date": info["expiry_date"]
            }
            update_activation_code(auth_code, update_data)
        except Exception:
            traceback.print_exc()
            fallback_activation_codes[auth_code] = info
    
    return {
        "status": "valid",
        "message": "激活码验证成功",
        "data": {
            "expiry_date": info["expiry_date"],
            "activated_date": info["activated_date"],
            "machine_code": info["machine_code"]
        }
    }

def handle_generate(body: dict) -> dict:
    """处理生成激活码请求"""
    duration = body.get("duration")
    count = body.get("count", 1)
    package_type = body.get("package_type")
    
    if duration is None or not package_type:
        return {
            "status": "error",
            "message": "缺少必填参数 duration 或 package_type",
            "data": None
        }
    
    # 验证duration
    allowed_durations = [1, 7, 30, 365, -1]
    if duration not in allowed_durations:
        return {
            "status": "error",
            "message": "duration 必须为 1、7、30、365 或 -1（永久）",
            "data": None
        }
    
    auth_codes = []
    generate_date = datetime.utcnow().isoformat() + 'Z'
    
    for _ in range(count):
        # 生成激活码
        encrypted = encrypt_data({
            "duration": duration,
            "package_type": package_type,
            "ts": int(time.time() * 1000) + _  # 保证每个激活码唯一
        })
        auth_code = f"{duration}_{encrypted}"
        
        # 存储数据
        info = {
            "auth_code": auth_code,
            "duration": duration,
            "package_type": package_type,
            "generate_date": generate_date,
            "activated_date": None,
            "machine_code": None,
            "expiry_date": None
        }
        
        # 写入存储
        try:
            insert_activation_code(info)
        except Exception:
            traceback.print_exc()
            fallback_activation_codes[auth_code] = info
        
        auth_codes.append(auth_code)
    
    return {
        "status": "success",
        "message": f"成功生成 {count} 个激活码",
        "data": {
            "auth_codes": auth_codes,
            "duration": duration,
            "generate_date": generate_date
        }
    }

# -------------------------- 主入口 --------------------------
def main_handler(event, context):
    """腾讯云函数入口"""
    # CORS头
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, X-API-Key"
    }
    
    # 获取客户端IP
    client_ip = event.get("requestContext", {}).get("sourceIp", 
                event.get("headers", {}).get("x-forwarded-for", "127.0.0.1"))
    
    # 频率限制
    if not check_rate_limit(client_ip):
        return {
            "statusCode": 429,
            "headers": headers,
            "body": json.dumps({
                "status": "error",
                "message": "请求过于频繁，请稍后再试",
                "data": None
            })
        }
    
    # 处理OPTIONS跨域
    http_method = event.get("httpMethod", "").upper()
    if http_method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": ""
        }
    
    # 验证API Key
    request_api_key = event.get("headers", {}).get("x-api-key", 
                    event.get("queryString", {}).get("apiKey", 
                    (event.get("body") if isinstance(event.get("body"), dict) else {}).get("apiKey")))
    if request_api_key != CONFIG["api_key"]:
        return {
            "statusCode": 401,
            "headers": headers,
            "body": json.dumps({
                "status": "error",
                "message": "API Key 无效",
                "data": None
            })
        }
    
    try:
        # 解析请求体
        body = event.get("body")
        if event.get("isBase64Encoded") and body:
            body = base64.b64decode(body).decode('utf-8')
        if isinstance(body, str):
            body = json.loads(body)
        
        path = event.get("path", "")
        result = None
        
        if path.endswith("/auth/verify") and http_method == "POST":
            result = handle_verify(body)
        elif path.endswith("/auth/generate") and http_method == "POST":
            result = handle_generate(body)
        else:
            return {
                "statusCode": 404,
                "headers": headers,
                "body": json.dumps({
                    "status": "error",
                    "message": "接口不存在",
                    "data": None
                })
            }
        
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps(result, ensure_ascii=False)
        }
        
    except Exception as e:
        traceback.print_exc()
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({
                "status": "error",
                "message": f"服务器内部错误: {str(e)}",
                "data": None
            }, ensure_ascii=False)
        }
